from django.urls import path
from . import views


urlpatterns = [
    path('', views.home, name='home'),  
    path('category/<int:category_id>/', views.category_detail, name='category_detail'),  
    path('news/<int:news_id>/', views.news_detail, name='news_detail'),  
    path('', views.home, name='home'), 
    path('ad/<int:ad_id>/', views.ad_detail, name='ad_detail'),
    path('add/', views.add_ad, name='add_ad'), 
    path('ads/', views.ad_list, name='ad_list'), 
    path('ad/<int:ad_id>/delete/', views.delete_ad, name='delete_ad'),
    path('category/add/', views.add_category, name='add_category')
]
