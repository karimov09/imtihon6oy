from django.shortcuts import render, get_object_or_404, redirect
from .models import Category, News, Elon
from .forms import ElonForm,CategoryForm
def home(request):
    categories = Category.objects.all()
    news = News.objects.all()
    ads = Elon.objects.all()
    context = {
        'categories': categories,
        'news': news,
        'ads': ads,
    }
    return render(request, 'home.html', context)

def category_detail(request, category_id):
    category = get_object_or_404(Category, id=category_id)
    news = News.objects.filter(category=category)
    return render(request, 'category_detail.html', {'category': category, 'news': news})

def news_detail(request, news_id):
    news_item = get_object_or_404(News, id=news_id)
    return render(request, 'news_detail.html', {'news': news_item})

def add_ad(request):
    if request.method == 'POST':
        title = request.POST.get('title')
        description = request.POST.get('description')
        price = request.POST.get('price')
        category_id = request.POST.get('category')
        
        category = Category.objects.get(id=category_id)

        ad = Elon(title=title, description=description, price=price, category=category)
        ad.save()
        return redirect('home')

    categories = Category.objects.all()
    return render(request, 'add_ad.html', {'categories': categories})



def ad_list(request):
    ads = Elon.objects.all()
    return render(request, 'ads/home.html', {'ads': ads})


def ad_detail(request, ad_id):
    ad = get_object_or_404(Elon, pk=ad_id)
    return render(request, 'ad_detail.html', {'ad': ad})

def add_ad(request):
    if request.method == 'POST':
        form = ElonForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            return redirect('home')
    else:
        form = ElonForm()
    return render(request, 'add_ad.html', {'form': form})

def delete_ad(request, ad_id):
    ad = get_object_or_404(Elon, pk=ad_id)
    if request.method == 'POST':
        ad.delete()
        return redirect('home')
    return render(request, 'delete_ad.html', {'ad': ad})

def add_category(request):
    if request.method == 'POST':
        form = CategoryForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('home') 
    else:
        form = CategoryForm()
    return render(request, 'add_category.html', {'form': form})
def post_detail(request, id):
    post = get_object_or_404(Elon, id=id)

    context = {
        'post': post
    }
    return render(request, 'post_detail.html', context)

