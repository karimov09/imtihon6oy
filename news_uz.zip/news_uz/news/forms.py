from django import forms
from .models import Elon,Category

class ElonForm(forms.ModelForm):
    class Meta: # Meta klassida biz qaysi modeldan foydalanilishini va qaysi maydonlar (fields) shaklda ko'rsatilishini aniqlaymiz. fields – bu shaklda ko'rsatiladigan model maydonlarining ro'yxati
        model = Elon
        fields = ['title', 'description', 'image', 'category']
class CategoryForm(forms.ModelForm):
    class Meta:
        model = Category
        fields = ['name']
        widgets = {
            'name': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Kategoriya nomini kiriting'}),
        }



